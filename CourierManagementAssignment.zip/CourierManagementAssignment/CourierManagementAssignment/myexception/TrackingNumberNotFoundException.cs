﻿namespace CourierManagementAssignment.myexception
{ 
public class TrackingNumberNotFoundException : Exception
{
    public TrackingNumberNotFoundException(string message) : base(message) { }
}
}