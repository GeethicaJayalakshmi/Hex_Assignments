﻿namespace CourierManagementAssignment.myexception
{ 
public class InvalidEmployeeIdException : Exception
{
    public InvalidEmployeeIdException(string message) : base(message) { }
}
}