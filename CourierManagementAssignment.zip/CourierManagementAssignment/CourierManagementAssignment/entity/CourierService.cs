﻿namespace CourierManagementAssignment.entity
{
    public class CourierService
    {
        public int ServiceID { get; set; }
        public string ServiceName { get; set; }
        public decimal Cost { get; set; }
    }
}
