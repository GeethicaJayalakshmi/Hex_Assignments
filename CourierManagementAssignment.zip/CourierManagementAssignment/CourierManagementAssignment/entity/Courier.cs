﻿namespace CourierManagementAssignment.entity
{
    public class Courier
    {
        public int CourierID { get; set; }
        public string SenderName { get; set; }
        public string SenderAddress { get; set; }
        public string ReceiverName { get; set; }
        public string ReceiverAddress { get; set; }

        // Use decimal to match DECIMAL(5,2) in the DB
        public decimal Weight { get; set; }

        public string Status { get; set; }
        public string TrackingNumber { get; set; }

        // Nullable because DeliveryDate can be NULL
        public DateTime? DeliveryDate { get; set; }

        // Foreign key to Users.UserID
        public int UserId { get; set; }
    }
}
