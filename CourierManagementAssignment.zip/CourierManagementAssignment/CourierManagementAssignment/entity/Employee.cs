﻿namespace CourierManagementAssignment.entity
{
    public class Employee
    {
        public long EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        public string Role { get; set; }
        public double Salary { get; set; }

        public Employee() { }

        public Employee(long employeeID, string employeeName, string email, string contactNumber, string role, double salary)
        {
            EmployeeID = employeeID;
            EmployeeName = employeeName;
            Email = email;
            ContactNumber = contactNumber;
            Role = role;
            Salary = salary;
        }

        public override string ToString()
        {
            return $"{EmployeeID} - {EmployeeName} - {Role} - {Salary}";
        }
    }
}
