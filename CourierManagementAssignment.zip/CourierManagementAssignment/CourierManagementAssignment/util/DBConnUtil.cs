﻿namespace CourierManagementAssignment.util
{
    using System.Data.SqlClient;

    /// <summary>
    /// Provides a method to get a new SqlConnection with hardcoded server configurations.
    /// </summary>
    public static class DBConnUtil
    {
        /// <returns>SqlConnection instance (not opened)</returns>
        public static SqlConnection GetConnection()
        {
            // Primary development server
            var conn1 = new SqlConnection("Server=LAPTOP-R19DI30G;Database=CourierManagement;Integrated Security=True;TrustServerCertificate=True");
            // Secondary local server
            var conn2 = new SqlConnection("Server=LAPTOP-R19DI30G;Database=CourierManagement;Integrated Security=True;TrustServerCertificate=True");

            // Return the first valid connection string; adjust as needed
            return conn1;
        }
    }
}
