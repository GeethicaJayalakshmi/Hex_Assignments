﻿using System;
using CourierManagementAssignment.dao;
using CourierManagementAssignment.entity;

namespace CourierManagementAssignment.main
{
    class Program
    {
        static void Main(string[] args)
        {
            ICourierUserService userSvc = new CourierUserServiceDb();
            ICourierAdminService adminSvc = new CourierAdminServiceDb();

            while (true)
            {
                Console.Clear();
                Console.WriteLine("--- Courier Management Menu ---");
                Console.WriteLine("1. Place Order");
                Console.WriteLine("2. Get Order Status");
                Console.WriteLine("3. Cancel Order");
                Console.WriteLine("4. Add Employee");
                Console.WriteLine("5. Exit");
                Console.Write("Select option: ");
                var opt = Console.ReadLine();

                try
                {
                    switch (opt)
                    {
                        case "1":
                            PlaceOrder(userSvc);
                            break;
                        case "2":
                            GetOrderStatus(userSvc);
                            break;
                        case "3":
                            CancelOrder(userSvc);
                            break;
                        case "4":
                            AddEmployee(adminSvc);
                            break;
                        case "5":
                            return;
                        default:
                            Console.WriteLine("Invalid option. Press any key to retry...");
                            Console.ReadKey();
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
            }
        }

        private static void PlaceOrder(ICourierUserService svc)
        {
            Console.WriteLine("--- Place New Order ---");
            var c = new Courier();
            Console.Write("Sender Name: "); c.SenderName = Console.ReadLine();
            Console.Write("Sender Address: "); c.SenderAddress = Console.ReadLine();
            Console.Write("Receiver Name: "); c.ReceiverName = Console.ReadLine();
            Console.Write("Receiver Address: "); c.ReceiverAddress = Console.ReadLine();
            Console.Write("Weight (kg): "); c.Weight = decimal.Parse(Console.ReadLine());
            Console.Write("Status: "); c.Status = Console.ReadLine();
            Console.Write("Expected Delivery Date (yyyy-MM-dd): ");
            c.DeliveryDate = DateTime.Parse(Console.ReadLine());
            Console.Write("User ID: "); c.UserId = int.Parse(Console.ReadLine());

            int newId = svc.PlaceOrder(c);
            Console.WriteLine($"Order placed successfully! New CourierID = {newId}");
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        private static void GetOrderStatus(ICourierUserService svc)
        {
            Console.WriteLine("--- Get Order Status ---");
            Console.Write("Tracking Number: ");
            string tk = Console.ReadLine();
            string status = svc.GetOrderStatus(tk);
            Console.WriteLine($"Status for {tk}: {status}");
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        private static void CancelOrder(ICourierUserService svc)
        {
            Console.WriteLine("--- Cancel Order ---");
            Console.Write("Tracking Number: ");
            string tk = Console.ReadLine();
            bool ok = svc.CancelOrder(tk);
            Console.WriteLine(ok ? "Order cancelled." : "Order not found or already cancelled.");
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        private static void AddEmployee(ICourierAdminService svc)
        {
            Console.WriteLine("--- Add New Employee ---");
            var e = new Employee();
            Console.Write("Employee Name: "); e.EmployeeName = Console.ReadLine();
            Console.Write("Email: "); e.Email = Console.ReadLine();
            Console.Write("Contact Number: "); e.ContactNumber = Console.ReadLine();
            Console.Write("Role: "); e.Role = Console.ReadLine();
            Console.Write("Salary: "); e.Salary = double.Parse(Console.ReadLine());

            int empId = svc.AddCourierStaff(e);
            Console.WriteLine($"Employee added successfully! New EmployeeID = {empId}");
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }
    }
}