﻿using CourierManagementAssignment.dao;
using CourierManagementAssignment.entity;
using CourierManagementAssignment.myexception;
using CourierManagementAssignment.util;
using System.Data.SqlClient;

namespace CourierManagementAssignment.dao
{
    public class CourierUserServiceDb : ICourierUserService
    {
        private readonly string _configFile = "dbconfig.properties";

        public int PlaceOrder(Courier courierObj)
        {
            using var conn = DBConnUtil.GetConnection();
            var cmd = new SqlCommand(
                "INSERT INTO Couriers (SenderName, SenderAddress, ReceiverName, ReceiverAddress, Weight, Status, TrackingNumber, DeliveryDate, UserID) " +
                "OUTPUT INSERTED.CourierID VALUES (@sn, @sa, @rn, @ra, @w, @st, @tk, @dd, @uid)", conn);
            cmd.Parameters.AddWithValue("@sn", courierObj.SenderName);
            cmd.Parameters.AddWithValue("@sa", courierObj.SenderAddress);
            cmd.Parameters.AddWithValue("@rn", courierObj.ReceiverName);
            cmd.Parameters.AddWithValue("@ra", courierObj.ReceiverAddress);
            cmd.Parameters.AddWithValue("@w", courierObj.Weight);
            cmd.Parameters.AddWithValue("@st", courierObj.Status);
            cmd.Parameters.AddWithValue("@tk", courierObj.TrackingNumber);
            cmd.Parameters.AddWithValue("@dd", (object)courierObj.DeliveryDate ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@uid", courierObj.UserId);
            return (int)cmd.ExecuteScalar();
        }

        public string GetOrderStatus(string trackingNumber)
        {
            using var conn = DBConnUtil.GetConnection();
            var cmd = new SqlCommand("SELECT Status FROM Couriers WHERE TrackingNumber = @tk", conn);
            cmd.Parameters.AddWithValue("@tk", trackingNumber);
            var result = cmd.ExecuteScalar();
            if (result == null) throw new TrackingNumberNotFoundException("Tracking number not found.");
            return result.ToString();
        }

        public bool CancelOrder(string trackingNumber)
        {
            using var conn = DBConnUtil.GetConnection();
            var cmd = new SqlCommand("UPDATE Couriers SET Status='Cancelled' WHERE TrackingNumber=@tk", conn);
            cmd.Parameters.AddWithValue("@tk", trackingNumber);
            return cmd.ExecuteNonQuery() > 0;
        }

        public List<Courier> GetAssignedOrder(int userId)
        {
            var list = new List<Courier>();
            using var conn = DBConnUtil.GetConnection();
            var cmd = new SqlCommand("SELECT * FROM Couriers WHERE UserID=@uid", conn);
            cmd.Parameters.AddWithValue("@uid", userId);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Courier
                {
                    CourierID = (int)reader["CourierID"],
                    SenderName = reader["SenderName"].ToString(),
                    SenderAddress = reader["SenderAddress"].ToString(),
                    ReceiverName = reader["ReceiverName"].ToString(),
                    ReceiverAddress = reader["ReceiverAddress"].ToString(),
                    Weight = (decimal)reader["Weight"],
                    Status = reader["Status"].ToString(),
                    TrackingNumber = reader["TrackingNumber"].ToString(),
                    DeliveryDate = reader["DeliveryDate"] as DateTime?,
                    UserId = (int)reader["UserID"]
                });
            }
            return list;
        }
    }
}