﻿using CourierManagementAssignment.entity;
using CourierManagementAssignment.util;
using System.Data.SqlClient;

namespace CourierManagementAssignment.dao

{
    public class CourierAdminServiceDb : ICourierAdminService
    {
        private readonly string _configFile = "dbconfig.properties";

        public int AddCourierStaff(Employee employee)
        {
            using var conn = DBConnUtil.GetConnection();
            var cmd = new SqlCommand(
                "INSERT INTO Employees (Name, Email, ContactNumber, Role, Salary) OUTPUT INSERTED.EmployeeID " +
                "VALUES (@n, @e, @c, @r, @s)", conn);
            cmd.Parameters.AddWithValue("@n", employee.EmployeeName);
            cmd.Parameters.AddWithValue("@e", employee.Email);
            cmd.Parameters.AddWithValue("@c", employee.ContactNumber);
            cmd.Parameters.AddWithValue("@r", employee.Role);
            cmd.Parameters.AddWithValue("@s", employee.Salary);
            return (int)cmd.ExecuteScalar();
        }
    }
}
