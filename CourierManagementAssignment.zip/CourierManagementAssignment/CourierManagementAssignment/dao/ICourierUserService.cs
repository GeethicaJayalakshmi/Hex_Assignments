﻿namespace CourierManagementAssignment.dao
{
    using CourierManagementAssignment.entity;
    using CourierManagementAssignment.myexception;
    using CourierManagementAssignment.util;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;

    public interface ICourierUserService
    {
        int PlaceOrder(Courier courierObj);
        string GetOrderStatus(string trackingNumber);
        bool CancelOrder(string trackingNumber);
        List<Courier> GetAssignedOrder(int userId);
    }

}