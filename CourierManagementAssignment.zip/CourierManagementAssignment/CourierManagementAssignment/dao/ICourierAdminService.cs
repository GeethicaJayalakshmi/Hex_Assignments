﻿using CourierManagementAssignment.entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourierManagementAssignment.dao
{
    public interface ICourierAdminService
    {
        int AddCourierStaff(Employee employee);
    }
}
