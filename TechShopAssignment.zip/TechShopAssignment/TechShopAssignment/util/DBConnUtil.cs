﻿using System;
using System.Data.SqlClient;

namespace TechShopAssignment.util
{
    public static class DBConnUtil
    {
        // Make connectionString a class-level static variable
        private static readonly string connectionString =
            "Server=LAPTOP-R19DI30G;Database=TechShop;Integrated Security=True;TrustServerCertificate=True";

        // Method to get a new SqlConnection with the default connection string
        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        // Optional: Method to get a SqlConnection with a custom connection string
        public static SqlConnection GetConnection(string connString)
        {
            return new SqlConnection(connString);
        }
    }
}
