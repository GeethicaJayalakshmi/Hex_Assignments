﻿using System;
using System.Collections.Generic;
using TechShop.entity;
using TechShopAssignment.dao;
using TechShopAssignment.entity;
using TechShopAssignment.implementation;

namespace TechShopManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            ITechShopDAO techShopDAO = new TechShopImplementation();
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("TechShop Management System");
                Console.WriteLine("1. Add Customer");
                Console.WriteLine("2. Add Product");
                Console.WriteLine("3. Place Order");
                Console.WriteLine("4. Add Order Details");
                Console.WriteLine("5. View Order Details");
                Console.WriteLine("6. View Customer Information");
                Console.WriteLine("7. Exit");
                Console.Write("Choose an option: ");

                string input = Console.ReadLine();
                if (int.TryParse(input, out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            AddCustomer(techShopDAO);
                            break;
                        case 2:
                            AddProduct(techShopDAO);
                            break;
                        case 3:
                            PlaceOrder(techShopDAO);
                            break;
                        case 4:
                            AddOrderDetails(techShopDAO);
                            break;
                        case 5:
                            ViewOrderDetails(techShopDAO);
                            break;
                        case 6:
                            ViewCustomerInformation(techShopDAO);
                            break;
                        case 7:
                            exit = true;
                            Console.WriteLine("Exiting the system...");
                            break;
                        default:
                            Console.WriteLine("Invalid choice! Please try again.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input! Please enter a valid number.");
                }
            }
        }

        static void AddCustomer(ITechShopDAO techShopDAO)
        {
            Console.WriteLine("Enter customer details:");
            Console.Write("Name: "); string name = Console.ReadLine();
            Console.Write("Email: "); string email = Console.ReadLine();

            Customer customer = new Customer(0, name, email);
            techShopDAO.AddCustomer(customer);
            Console.WriteLine("Customer added successfully!");
        }

        static void AddProduct(ITechShopDAO techShopDAO)
        {
            Console.WriteLine("Enter product details:");
            Console.Write("Name: "); string name = Console.ReadLine();
            Console.Write("Price: "); double price = double.Parse(Console.ReadLine());

            Product product = new Product(0, name, price);
            techShopDAO.AddProduct(product);
            Console.WriteLine("Product added successfully!");
        }

        static void PlaceOrder(ITechShopDAO techShopDAO)
        {
            Console.Write("Enter customer ID: "); int customerId = int.Parse(Console.ReadLine());
            Console.Write("Enter total amount: "); double total = double.Parse(Console.ReadLine());

            Order order = new Order(0, customerId, DateTime.Now,total);
            int orderId = techShopDAO.PlaceOrder(order);
            Console.WriteLine($"Order placed successfully with Order ID: {orderId}");
        }

        static void AddOrderDetails(ITechShopDAO techShopDAO)
        {
            Console.Write("Enter Order ID: "); int orderId = int.Parse(Console.ReadLine());
            Console.Write("Enter Product ID: "); int productId = int.Parse(Console.ReadLine());
            Console.Write("Enter Quantity: "); int quantity = int.Parse(Console.ReadLine());
            Console.Write("Enter Price: "); decimal price = decimal.Parse(Console.ReadLine());

            OrderDetails details = new OrderDetails(orderId, productId, quantity, price);
            techShopDAO.AddOrderDetails(details);
            Console.WriteLine("Order details added successfully!");
        }

        static void ViewOrderDetails(ITechShopDAO techShopDAO)
        {
            Console.Write("Enter Order ID: "); int orderId = int.Parse(Console.ReadLine());
            Order order = techShopDAO.GetOrderById(orderId);
            if (order != null)
            {
                Console.WriteLine($"Order ID: {order.OrderId}, Total Amount: {order.TotalAmount}");
                List<OrderDetails> details = techShopDAO.GetOrderDetailsByOrderId(orderId);
                foreach (var detail in details)
                {
                    Console.WriteLine($"Product ID: {detail.ProductId}, Quantity: {detail.Quantity}, Price: {detail.Price}");
                }
            }
            else
            {
                Console.WriteLine("Order not found!");
            }
        }

        static void ViewCustomerInformation(ITechShopDAO techShopDAO)
        {
            Console.Write("Enter Customer ID: "); int customerId = int.Parse(Console.ReadLine());
            Customer customer = techShopDAO.GetCustomerById(customerId);
            if (customer != null)
            {
                Console.WriteLine($"Customer ID: {customer.CustomerId}, Name: {customer.Name}, Email: {customer.Email}");
            }
            else
            {
                Console.WriteLine("Customer not found!");
            }
        }
    }
}
