﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using TechShopAssignment.entity;
using TechShopAssignment.dao;
using TechShop.entity;

namespace TechShopAssignment.implementation
{
    public class TechShopImplementation : ITechShopDAO
    {
        // Database connection string (Update it as per your configuration)
        private readonly string connectionString = "Server=LAPTOP-R19DI30G;Database=TechShop;Integrated Security=True;TrustServerCertificate=True";

        // Add a new customer to the database
        public void AddCustomer(Customer customer)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Customers (Name, Email) VALUES (@Name, @Email)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", customer.Name);
                command.Parameters.AddWithValue("@Email", customer.Email);
                command.ExecuteNonQuery();
            }
        }

        // Get a customer by their ID
        public Customer GetCustomerById(int customerId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Customers WHERE CustomerId = @CustomerId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CustomerId", customerId);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    return new Customer(
                        customerId,
                        reader["Name"].ToString(),
                        reader["Email"].ToString()
                    );
                }
                else
                {
                    return null;
                }
            }
        }

        // Get all products from the database
        public List<Product> GetAllProducts()
        {
            List<Product> products = new List<Product>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Products";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    products.Add(new Product(
                        Convert.ToInt32(reader["ProductId"]),
                        reader["ProductName"].ToString(),
                        Convert.ToDouble(reader["Price"])
                    ));
                }
            }

            return products;
        }

        // Add a new product to the database
        public void AddProduct(Product product)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Products (ProductName, Price) VALUES (@ProductName, @Price)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ProductName", product.ProductName);
                command.Parameters.AddWithValue("@Price", product.Price);
                command.ExecuteNonQuery();
            }
        }

        // Get a product by its ID
        public Product GetProductById(int productId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Products WHERE ProductId = @ProductId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ProductId", productId);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    return new Product(
                        productId,
                        reader["ProductName"].ToString(),
                        Convert.ToDouble(reader["Price"])
                    );
                }
                else
                {
                    return null;
                }
            }
        }

        // Add inventory for a product
        public void AddInventory(Inventory inventory)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Inventories (ProductId, QuantityAvailable) VALUES (@ProductId, @QuantityAvailable)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ProductId", inventory.ProductId);
                command.Parameters.AddWithValue("@QuantityAvailable", inventory.QuantityAvailable);
                command.ExecuteNonQuery();
            }
        }

        // Get inventory by product ID
        public Inventory GetInventoryByProductId(int productId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Inventories WHERE ProductId = @ProductId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ProductId", productId);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    return new Inventory(
                        productId,
                        Convert.ToInt32(reader["QuantityAvailable"])
                    );
                }
                else
                {
                    return null;
                }
            }
        }

        // Place an order and return the OrderId
        public int PlaceOrder(Order order)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Orders (CustomerId, OrderDate, TotalAmount) OUTPUT INSERTED.OrderId VALUES (@CustomerId, @OrderDate, @TotalAmount)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CustomerId", order.CustomerId);
                command.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                command.Parameters.AddWithValue("@TotalAmount", order.TotalAmount);

                return Convert.ToInt32(command.ExecuteScalar());
            }
        }

        // Get an order by its ID
        public Order GetOrderById(int orderId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Orders WHERE OrderId = @OrderId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@OrderId", orderId);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    return new Order(
                        orderId,
                        Convert.ToInt32(reader["CustomerId"]),
                        Convert.ToDateTime(reader["OrderDate"]),
                        Convert.ToDouble(reader["TotalAmount"])
                    );
                }
                else
                {
                    return null;
                }
            }
        }

        // Add order details
        public void AddOrderDetails(OrderDetails orderDetails)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO OrderDetails (OrderId, ProductId, Quantity, Price) VALUES (@OrderId, @ProductId, @Quantity, @Price)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@OrderId", orderDetails.OrderId);
                command.Parameters.AddWithValue("@ProductId", orderDetails.ProductId);
                command.Parameters.AddWithValue("@Quantity", orderDetails.Quantity);
                command.Parameters.AddWithValue("@Price", orderDetails.Price);
                command.ExecuteNonQuery();
            }
        }

        // Get order details by order ID
        public List<OrderDetails> GetOrderDetailsByOrderId(int orderId)
        {
            List<OrderDetails> orderDetailsList = new List<OrderDetails>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM OrderDetails WHERE OrderId = @OrderId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@OrderId", orderId);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    orderDetailsList.Add(new OrderDetails(
                        Convert.ToInt32(reader["OrderId"]),
                        Convert.ToInt32(reader["ProductId"]),
                        Convert.ToInt32(reader["Quantity"]),
                        Convert.ToDecimal(reader["Price"])
                    ));
                }
            }

            return orderDetailsList;
        }
    }
}
