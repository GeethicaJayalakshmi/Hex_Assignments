﻿using TechShop.entity;
using TechShopAssignment.entity;

namespace TechShopAssignment.dao
{
    public interface ITechShopDAO
    {
        // Existing methods
        void AddCustomer(Customer customer);
        Customer GetCustomerById(int customerId);
        List<Product> GetAllProducts();
        void AddInventory(Inventory inventory);
        Inventory GetInventoryByProductId(int productId);
        int PlaceOrder(Order order);
        Order GetOrderById(int orderId);
        void AddOrderDetails(OrderDetails orderDetails);
        List<OrderDetails> GetOrderDetailsByOrderId(int orderId);

        // New methods for Product
        void AddProduct(Product product); // Method to add a new product
        Product GetProductById(int productId); // Method to get a product by ID
    }
}
