﻿namespace TechShop.entity
{
    public class Order
    {
        public int OrderId { get; set; }
        public int CustomerId { get; set; }
        public DateTime OrderDate { get; set; }
        public double TotalAmount { get; set; }

        public Order() { }

        public Order(int orderId, int customerId, DateTime orderDate, double totalAmount)
        {
            OrderId = orderId;
            CustomerId = customerId;
            OrderDate = orderDate;
            TotalAmount = totalAmount;
        }

        public override string ToString()
        {
            return $"OrderId: {OrderId}, CustomerId: {CustomerId}, OrderDate: {OrderDate}, TotalAmount: {TotalAmount}";
        }
    }
}
