﻿namespace TechShop.entity
{
    public class Inventory
    {
        public int ProductId { get; set; }
        public int QuantityAvailable { get; set; }

        public Inventory() { }

        public Inventory(int productId, int quantityAvailable)
        {
            ProductId = productId;
            QuantityAvailable = quantityAvailable;
        }

        public override string ToString()
        {
            return $"ProductId: {ProductId}, QuantityAvailable: {QuantityAvailable}";
        }
    }
}
