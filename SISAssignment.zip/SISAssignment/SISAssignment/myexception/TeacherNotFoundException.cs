﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SISAssignment.myexception
{
    public class TeacherNotFoundException : Exception
    {
        public TeacherNotFoundException(string message) : base(message) { }
    }
}
