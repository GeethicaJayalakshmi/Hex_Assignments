﻿namespace SISAssignment.Entity
{
    public class Teacher
    {
        public int TeacherId { get; set; }
        public string Name { get; set; }
        public int DepartmentId { get; set; }

        public Teacher() { }

        public Teacher(int teacherId, string name, int departmentId)
        {
            TeacherId = teacherId;
            Name = name;
            DepartmentId = departmentId;
        }
    }
}
