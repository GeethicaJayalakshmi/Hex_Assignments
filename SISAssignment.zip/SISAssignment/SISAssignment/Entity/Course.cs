﻿namespace SISAssignment.Entity
{
    public class Course
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public int CreditHours { get; set; }

        public Course() { }

        public Course(int courseId, string courseName, int creditHours)
        {
            CourseId = courseId;
            CourseName = courseName;
            CreditHours = creditHours;
        }
    }
}
