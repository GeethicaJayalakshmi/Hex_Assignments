﻿namespace SISAssignment.Entity
{
    public class Student
    {
        public int StudentId { get; set; }
        public string Name { get; set; }
        public DateTime DOB { get; set; }
        public string Email { get; set; }

        public Student() { }

        public Student(int studentId, string name, DateTime dob, string email)
        {
            StudentId = studentId;
            Name = name;
            DOB = dob;
            Email = email;
        }
    }
}
