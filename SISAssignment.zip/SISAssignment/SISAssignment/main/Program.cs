﻿using System;
using SISAssignment.dao;
using SISAssignment.Entity;

namespace SISAssignment.main
{
    class Program
    {
        static void Main(string[] args)
        {
            IStudentDAO dao = new StudentDAO();
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("\n--- Student Information System ---");
                Console.WriteLine("1. Manage Students");
                Console.WriteLine("2. Manage Courses");
                Console.WriteLine("3. Manage Departments");
                Console.WriteLine("4. Manage Teachers");
                Console.WriteLine("5. Exit");
                Console.Write("Enter your choice: ");
                int mainChoice = Convert.ToInt32(Console.ReadLine());

                switch (mainChoice)
                {
                    case 1:
                        ManageStudents(dao);
                        break;
                    case 2:
                        ManageCourses(dao);
                        break;
                    case 3:
                        ManageDepartments(dao);
                        break;
                    case 4:
                        ManageTeachers(dao);
                        break;
                    case 5:
                        exit = true;
                        Console.WriteLine("Exiting program...");
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Try again.");
                        break;
                }
            }
        }

        // Manage Students
        static void ManageStudents(IStudentDAO dao)
        {
            bool back = false;
            while (!back)
            {
                Console.WriteLine("\n--- Manage Students ---");
                Console.WriteLine("1. Add Student");
                Console.WriteLine("2. View Student");
                Console.WriteLine("3. View All Students");
                Console.WriteLine("4. Update Student");
                Console.WriteLine("5. Delete Student");
                Console.WriteLine("6. Back to Main Menu");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Write("Enter Student Id: ");
                        int id = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Student Name: ");
                        string name = Console.ReadLine();
                        Console.Write("Enter Date of Birth (yyyy-MM-dd): ");
                        DateTime dob = DateTime.Parse(Console.ReadLine());
                        Console.Write("Enter Email: ");
                        string email = Console.ReadLine();
                        dao.AddStudent(new Student(id, name, dob, email));
                        break;

                    case 2:
                        Console.Write("Enter Student Id: ");
                        int searchId = Convert.ToInt32(Console.ReadLine());
                        var student = dao.GetStudent(searchId);
                        if (student != null)
                        {
                            Console.WriteLine($"ID: {student.StudentId}, Name: {student.Name}, DOB: {student.DOB.ToShortDateString()}, Email: {student.Email}");
                        }
                        else
                        {
                            Console.WriteLine("Student not found.");
                        }
                        break;

                    case 3:
                        var allStudents = dao.GetAllStudents();
                        foreach (var stud in allStudents)
                        {
                            Console.WriteLine($"ID: {stud.StudentId}, Name: {stud.Name}, DOB: {stud.DOB.ToShortDateString()}, Email: {stud.Email}");
                        }
                        break;

                    case 4:
                        Console.Write("Enter Student Id to update: ");
                        int updateId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter New Name: ");
                        string newName = Console.ReadLine();
                        Console.Write("Enter New DOB (yyyy-MM-dd): ");
                        DateTime newDob = DateTime.Parse(Console.ReadLine());
                        Console.Write("Enter New Email: ");
                        string newEmail = Console.ReadLine();
                        dao.UpdateStudent(new Student(updateId, newName, newDob, newEmail));
                        break;

                    case 5:
                        Console.Write("Enter Student Id to delete: ");
                        int deleteId = Convert.ToInt32(Console.ReadLine());
                        dao.DeleteStudent(deleteId);
                        break;

                    case 6:
                        back = true;
                        break;

                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }
            }
        }

        // Manage Courses
        static void ManageCourses(IStudentDAO dao)
        {
            bool back = false;
            while (!back)
            {
                Console.WriteLine("\n--- Manage Courses ---");
                Console.WriteLine("1. Add Course");
                Console.WriteLine("2. View Course");
                Console.WriteLine("3. View All Courses");
                Console.WriteLine("4. Update Course");
                Console.WriteLine("5. Delete Course");
                Console.WriteLine("6. Back to Main Menu");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Write("Enter Course Id: ");
                        int courseId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Course Name: ");
                        string courseName = Console.ReadLine();
                        Console.Write("Enter Credit Hours: ");
                        int creditHours = Convert.ToInt32(Console.ReadLine());
                        dao.AddCourse(new Course(courseId, courseName, creditHours));
                        break;

                    case 2:
                        Console.Write("Enter Course Id: ");
                        int searchCourseId = Convert.ToInt32(Console.ReadLine());
                        var course = dao.GetCourse(searchCourseId);
                        if (course != null)
                        {
                            Console.WriteLine($"ID: {course.CourseId}, Name: {course.CourseName}, Credit Hours: {course.CreditHours}");
                        }
                        else
                        {
                            Console.WriteLine("Course not found.");
                        }
                        break;

                    case 3:
                        var allCourses = dao.GetAllCourses();
                        foreach (var crs in allCourses)
                        {
                            Console.WriteLine($"ID: {crs.CourseId}, Name: {crs.CourseName}, Credit Hours: {crs.CreditHours}");
                        }
                        break;

                    case 4:
                        Console.Write("Enter Course Id to update: ");
                        int updateCourseId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter New Name: ");
                        string newCourseName = Console.ReadLine();
                        Console.Write("Enter New Credit Hours: ");
                        int newCreditHours = Convert.ToInt32(Console.ReadLine());
                        dao.UpdateCourse(new Course(updateCourseId, newCourseName, newCreditHours));
                        break;

                    case 5:
                        Console.Write("Enter Course Id to delete: ");
                        int deleteCourseId = Convert.ToInt32(Console.ReadLine());
                        dao.DeleteCourse(deleteCourseId);
                        break;

                    case 6:
                        back = true;
                        break;

                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }
            }
        }

        // Manage Departments
        static void ManageDepartments(IStudentDAO dao)
        {
            bool back = false;
            while (!back)
            {
                Console.WriteLine("\n--- Manage Departments ---");
                Console.WriteLine("1. Add Department");
                Console.WriteLine("2. View Department");
                Console.WriteLine("3. View All Departments");
                Console.WriteLine("4. Update Department");
                Console.WriteLine("5. Delete Department");
                Console.WriteLine("6. Back to Main Menu");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Write("Enter Department Id: ");
                        int departmentId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Department Name: ");
                        string departmentName = Console.ReadLine();
                        dao.AddDepartment(new Department(departmentId, departmentName));
                        break;

                    case 2:
                        Console.Write("Enter Department Id: ");
                        int searchDepartmentId = Convert.ToInt32(Console.ReadLine());
                        var department = dao.GetDepartment(searchDepartmentId);
                        if (department != null)
                        {
                            Console.WriteLine($"ID: {department.DepartmentId}, Name: {department.DepartmentName}");
                        }
                        else
                        {
                            Console.WriteLine("Department not found.");
                        }
                        break;

                    case 3:
                        var allDepartments = dao.GetAllDepartments();
                        foreach (var dept in allDepartments)
                        {
                            Console.WriteLine($"ID: {dept.DepartmentId}, Name: {dept.DepartmentName}");
                        }
                        break;

                    case 4:
                        Console.Write("Enter Department Id to update: ");
                        int updateDepartmentId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter New Department Name: ");
                        string newDepartmentName = Console.ReadLine();
                        dao.UpdateDepartment(new Department(updateDepartmentId, newDepartmentName));
                        break;

                    case 5:
                        Console.Write("Enter Department Id to delete: ");
                        int deleteDepartmentId = Convert.ToInt32(Console.ReadLine());
                        dao.DeleteDepartment(deleteDepartmentId);
                        break;

                    case 6:
                        back = true;
                        break;

                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }
            }
        }

        // Manage Teachers
        static void ManageTeachers(IStudentDAO dao)
        {
            bool back = false;
            while (!back)
            {
                Console.WriteLine("\n--- Manage Teachers ---");
                Console.WriteLine("1. Add Teacher");
                Console.WriteLine("2. View Teacher");
                Console.WriteLine("3. View All Teachers");
                Console.WriteLine("4. Update Teacher");
                Console.WriteLine("5. Delete Teacher");
                Console.WriteLine("6. Back to Main Menu");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Write("Enter Teacher Id: ");
                        int teacherId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Teacher Name: ");
                        string teacherName = Console.ReadLine();
                        Console.Write("Enter Department Id: ");
                        int deptId = Convert.ToInt32(Console.ReadLine());
                        dao.AddTeacher(new Teacher(teacherId, teacherName, deptId));
                        break;

                    case 2:
                        Console.Write("Enter Teacher Id: ");
                        int searchTeacherId = Convert.ToInt32(Console.ReadLine());
                        var teacher = dao.GetTeacher(searchTeacherId);
                        if (teacher != null)
                        {
                            Console.WriteLine($"ID: {teacher.TeacherId}, Name: {teacher.Name}, DepartmentId: {teacher.DepartmentId}");
                        }
                        else
                        {
                            Console.WriteLine("Teacher not found.");
                        }
                        break;

                    case 3:
                        var allTeachers = dao.GetAllTeachers();
                        foreach (var teach in allTeachers)
                        {
                            Console.WriteLine($"ID: {teach.TeacherId}, Name: {teach.Name}, DepartmentId: {teach.DepartmentId}");
                        }
                        break;

                    case 4:
                        Console.Write("Enter Teacher Id to update: ");
                        int updateTeacherId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter New Name: ");
                        string newTeacherName = Console.ReadLine();
                        Console.Write("Enter New Department Id: ");
                        int newDeptId = Convert.ToInt32(Console.ReadLine());
                        dao.UpdateTeacher(new Teacher(updateTeacherId, newTeacherName, newDeptId));
                        break;

                    case 5:
                        Console.Write("Enter Teacher Id to delete: ");
                        int deleteTeacherId = Convert.ToInt32(Console.ReadLine());
                        dao.DeleteTeacher(deleteTeacherId);
                        break;

                    case 6:
                        back = true;
                        break;

                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }
            }
        }
    }
}
