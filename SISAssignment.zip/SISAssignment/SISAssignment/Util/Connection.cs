﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace SISAssignment.Util
{
    public static class Connection
    {
        private static readonly string connectionString =
            "Server=LAPTOP-R19DI30G;Database=SISDB;Integrated Security=True;TrustServerCertificate=True";

        // Always return a NEW, unopened SqlConnection
        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }

}
