﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SISAssignment.Util
{
    public static class Properties
    {
        public static string GetConnectionString()
        {
            // Hardcoded connection string (update if needed)
            return "Server=LAPTOP-R19DI30G;Database=SISDB;Integrated Security=True;TrustServerCertificate=True";
        }
    }

}
