﻿using System;
using System.Collections.Generic;
using SISAssignment.Entity;

namespace SISAssignment.dao
{
    public class StudentDAO : IStudentDAO
    {
        private List<Student> students = new List<Student>();
        private List<Course> courses = new List<Course>();
        private List<Department> departments = new List<Department>();
        private List<Teacher> teachers = new List<Teacher>();

        // ---------- Student Methods ----------
        public void AddStudent(Student student)
        {
            students.Add(student);
            Console.WriteLine("Student added successfully.");
        }

        public Student GetStudent(int studentId)
        {
            return students.Find(s => s.StudentId == studentId);
        }

        public List<Student> GetAllStudents()
        {
            return students;
        }

        public void UpdateStudent(Student student)
        {
            var existingStudent = GetStudent(student.StudentId);
            if (existingStudent != null)
            {
                existingStudent.Name = student.Name;
                existingStudent.DOB = student.DOB;
                existingStudent.Email = student.Email;
                Console.WriteLine("Student updated successfully.");
            }
            else
            {
                Console.WriteLine("Student not found.");
            }
        }

        public void DeleteStudent(int studentId)
        {
            var student = GetStudent(studentId);
            if (student != null)
            {
                students.Remove(student);
                Console.WriteLine("Student deleted successfully.");
            }
            else
            {
                Console.WriteLine("Student not found.");
            }
        }

        // ---------- Course Methods ----------
        public void AddCourse(Course course)
        {
            courses.Add(course);
            Console.WriteLine("Course added successfully.");
        }

        public Course GetCourse(int courseId)
        {
            return courses.Find(c => c.CourseId == courseId);
        }

        public List<Course> GetAllCourses()
        {
            return courses;
        }

        public void UpdateCourse(Course course)
        {
            var existingCourse = GetCourse(course.CourseId);
            if (existingCourse != null)
            {
                existingCourse.CourseName = course.CourseName;
                existingCourse.CreditHours = course.CreditHours;
                Console.WriteLine("Course updated successfully.");
            }
            else
            {
                Console.WriteLine("Course not found.");
            }
        }

        public void DeleteCourse(int courseId)
        {
            var course = GetCourse(courseId);
            if (course != null)
            {
                courses.Remove(course);
                Console.WriteLine("Course deleted successfully.");
            }
            else
            {
                Console.WriteLine("Course not found.");
            }
        }

        // ---------- Department Methods ----------
        public void AddDepartment(Department department)
        {
            departments.Add(department);
            Console.WriteLine("Department added successfully.");
        }

        public Department GetDepartment(int departmentId)
        {
            return departments.Find(d => d.DepartmentId == departmentId);
        }

        public List<Department> GetAllDepartments()
        {
            return departments;
        }

        public void UpdateDepartment(Department department)
        {
            var existingDepartment = GetDepartment(department.DepartmentId);
            if (existingDepartment != null)
            {
                existingDepartment.DepartmentName = department.DepartmentName;
                Console.WriteLine("Department updated successfully.");
            }
            else
            {
                Console.WriteLine("Department not found.");
            }
        }

        public void DeleteDepartment(int departmentId)
        {
            var department = GetDepartment(departmentId);
            if (department != null)
            {
                departments.Remove(department);
                Console.WriteLine("Department deleted successfully.");
            }
            else
            {
                Console.WriteLine("Department not found.");
            }
        }

        // ---------- Teacher Methods ----------
        public void AddTeacher(Teacher teacher)
        {
            teachers.Add(teacher);
            Console.WriteLine("Teacher added successfully.");
        }

        public Teacher GetTeacher(int teacherId)
        {
            return teachers.Find(t => t.TeacherId == teacherId);
        }

        public List<Teacher> GetAllTeachers()
        {
            return teachers;
        }

        public void UpdateTeacher(Teacher teacher)
        {
            var existingTeacher = GetTeacher(teacher.TeacherId);
            if (existingTeacher != null)
            {
                existingTeacher.Name = teacher.Name;
                existingTeacher.DepartmentId = teacher.DepartmentId;
                Console.WriteLine("Teacher updated successfully.");
            }
            else
            {
                Console.WriteLine("Teacher not found.");
            }
        }

        public void DeleteTeacher(int teacherId)
        {
            var teacher = GetTeacher(teacherId);
            if (teacher != null)
            {
                teachers.Remove(teacher);
                Console.WriteLine("Teacher deleted successfully.");
            }
            else
            {
                Console.WriteLine("Teacher not found.");
            }
        }
    }
}
