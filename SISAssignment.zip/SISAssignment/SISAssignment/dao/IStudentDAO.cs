﻿using System.Collections.Generic;
using SISAssignment.Entity;

namespace SISAssignment.dao
{
    public interface IStudentDAO
    {
        // Student Methods
        void AddStudent(Student student);
        Student GetStudent(int studentId);
        List<Student> GetAllStudents();
        void UpdateStudent(Student student);
        void DeleteStudent(int studentId);

        // Course Methods
        void AddCourse(Course course);
        Course GetCourse(int courseId);
        List<Course> GetAllCourses();
        void UpdateCourse(Course course);
        void DeleteCourse(int courseId);

        // Department Methods
        void AddDepartment(Department department);
        Department GetDepartment(int departmentId);
        List<Department> GetAllDepartments();
        void UpdateDepartment(Department department);
        void DeleteDepartment(int departmentId);

        // Teacher Methods
        void AddTeacher(Teacher teacher);
        Teacher GetTeacher(int teacherId);
        List<Teacher> GetAllTeachers();
        void UpdateTeacher(Teacher teacher);
        void DeleteTeacher(int teacherId);
    }
}
