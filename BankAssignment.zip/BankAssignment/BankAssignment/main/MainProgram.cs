﻿using BankAssignment.dao;
using BankAssignment.Entity;
using BankAssignment.myexception;
using System;

namespace BankAssignment.main
{
    public class MainModule
    {
        public static void Main(string[] args)
        {
            IBankingService service = new BankingServiceImpl();
            while (true)
            {
                Console.WriteLine("\n--- Banking System Menu ---");
                Console.WriteLine("1. Create Customer\n2. Create Account\n3. Deposit\n4. Withdraw\n5. View Transactions\n6. Exit");
                Console.Write("Enter your choice: ");

                if (!int.TryParse(Console.ReadLine(), out int choice))
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                    continue;
                }

                try
                {
                    switch (choice)
                    {
                        case 1:
                            Console.Write("Enter name: ");
                            string name = Console.ReadLine();
                            Console.Write("Enter email: ");
                            string email = Console.ReadLine();
                            service.CreateCustomer(new Customer { Name = name, Email = email });
                            Console.WriteLine("Customer created successfully.");
                            break;

                        case 2:
                            Console.Write("Enter customer ID: ");
                            if (!int.TryParse(Console.ReadLine(), out int custId))
                            {
                                Console.WriteLine("Invalid Customer ID.");
                                break;
                            }
                            Console.Write("Enter initial balance: ");
                            if (!decimal.TryParse(Console.ReadLine(), out decimal balance))
                            {
                                Console.WriteLine("Invalid balance.");
                                break;
                            }
                            service.CreateAccount(new Account { CustomerId = custId, Balance = balance });
                            Console.WriteLine("Account created successfully.");
                            break;

                        case 3:
                            Console.Write("Enter account ID: ");
                            if (!int.TryParse(Console.ReadLine(), out int accIdD))
                            {
                                Console.WriteLine("Invalid account ID.");
                                break;
                            }
                            Console.Write("Enter deposit amount: ");
                            if (!decimal.TryParse(Console.ReadLine(), out decimal deposit))
                            {
                                Console.WriteLine("Invalid deposit amount.");
                                break;
                            }
                            service.Deposit(accIdD, deposit);
                            Console.WriteLine("Deposit successful.");
                            break;

                        case 4:
                            Console.Write("Enter account ID: ");
                            if (!int.TryParse(Console.ReadLine(), out int accIdW))
                            {
                                Console.WriteLine("Invalid account ID.");
                                break;
                            }
                            Console.Write("Enter withdrawal amount: ");
                            if (!decimal.TryParse(Console.ReadLine(), out decimal withdrawal))
                            {
                                Console.WriteLine("Invalid withdrawal amount.");
                                break;
                            }
                            service.Withdraw(accIdW, withdrawal);
                            Console.WriteLine("Withdrawal successful.");
                            break;

                        case 5:
                            Console.Write("Enter account ID: ");
                            if (!int.TryParse(Console.ReadLine(), out int accIdT))
                            {
                                Console.WriteLine("Invalid account ID.");
                                break;
                            }
                            var txns = service.GetTransactions(accIdT);
                            if (txns.Count == 0)
                                Console.WriteLine("No transactions found.");
                            foreach (var txn in txns)
                                Console.WriteLine($"{txn.TransactionDate}: {txn.Type} - Rs.{txn.Amount}");
                            break;

                        case 6:
                            return;

                        default:
                            Console.WriteLine("Invalid choice");
                            break;
                    }
                }
                catch (InsufficientFundsException ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Unexpected Error: " + ex.Message);
                }
            }
        }
    }
}