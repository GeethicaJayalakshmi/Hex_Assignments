﻿using BankAssignment.Entity;
using System.Collections.Generic;

namespace BankAssignment.dao
{
    public interface IBankingService
    {
        void CreateCustomer(Customer customer);
        void CreateAccount(Account account);
        void Deposit(int accountId, decimal amount);
        void Withdraw(int accountId, decimal amount);
        List<Transaction> GetTransactions(int accountId);
    }
}