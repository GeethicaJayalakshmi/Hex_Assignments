﻿using BankAssignment.Entity;
using BankAssignment.myexception;
using BankAssignment.util;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace BankAssignment.dao
{
    public class BankingServiceImpl : IBankingService
    {
        private string connectionString;

        public BankingServiceImpl()
        {
            connectionString = DBPropertyUtil.GetConnectionString("BankingDB");
        }

        public void CreateCustomer(Customer customer)
        {
            using SqlConnection conn = DBConnUtil.GetConnection(connectionString);
            conn.Open();
            string query = "INSERT INTO Customers (Name, Email) VALUES (@Name, @Email)";
            using SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Name", customer.Name);
            cmd.Parameters.AddWithValue("@Email", customer.Email);
            cmd.ExecuteNonQuery();
        }

        public void CreateAccount(Account account)
        {
            using SqlConnection conn = DBConnUtil.GetConnection(connectionString);
            conn.Open();
            string query = "INSERT INTO Accounts (CustomerId, Balance) VALUES (@CustomerId, @Balance)";
            using SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@CustomerId", account.CustomerId);
            cmd.Parameters.AddWithValue("@Balance", account.Balance);
            cmd.ExecuteNonQuery();
        }

        public void Deposit(int accountId, decimal amount)
        {
            using SqlConnection conn = DBConnUtil.GetConnection(connectionString);
            conn.Open();
            string updateQuery = "UPDATE Accounts SET Balance = Balance + @Amount WHERE AccountId = @AccountId";
            string insertTransaction = "INSERT INTO Transactions (AccountId, Type, Amount, TransactionDate) VALUES (@AccountId, 'Deposit', @Amount, @Date)";

            using SqlCommand cmd1 = new SqlCommand(updateQuery, conn);
            cmd1.Parameters.AddWithValue("@Amount", amount);
            cmd1.Parameters.AddWithValue("@AccountId", accountId);
            cmd1.ExecuteNonQuery();

            using SqlCommand cmd2 = new SqlCommand(insertTransaction, conn);
            cmd2.Parameters.AddWithValue("@AccountId", accountId);
            cmd2.Parameters.AddWithValue("@Amount", amount);
            cmd2.Parameters.AddWithValue("@Date", DateTime.Now);
            cmd2.ExecuteNonQuery();
        }

        public void Withdraw(int accountId, decimal amount)
        {
            using SqlConnection conn = DBConnUtil.GetConnection(connectionString);
            conn.Open();
            string balanceCheck = "SELECT Balance FROM Accounts WHERE AccountId = @AccountId";
            using SqlCommand checkCmd = new SqlCommand(balanceCheck, conn);
            checkCmd.Parameters.AddWithValue("@AccountId", accountId);
            object result = checkCmd.ExecuteScalar();

            if (result == null)
                throw new Exception("Account not found.");

            decimal balance = (decimal)result;

            if (balance < amount)
                throw new InsufficientFundsException("Insufficient funds for withdrawal.");

            string updateQuery = "UPDATE Accounts SET Balance = Balance - @Amount WHERE AccountId = @AccountId";
            string insertTransaction = "INSERT INTO Transactions (AccountId, Type, Amount, TransactionDate) VALUES (@AccountId, 'Withdrawal', @Amount, @Date)";

            using SqlCommand cmd1 = new SqlCommand(updateQuery, conn);
            cmd1.Parameters.AddWithValue("@Amount", amount);
            cmd1.Parameters.AddWithValue("@AccountId", accountId);
            cmd1.ExecuteNonQuery();

            using SqlCommand cmd2 = new SqlCommand(insertTransaction, conn);
            cmd2.Parameters.AddWithValue("@AccountId", accountId);
            cmd2.Parameters.AddWithValue("@Amount", amount);
            cmd2.Parameters.AddWithValue("@Date", DateTime.Now);
            cmd2.ExecuteNonQuery();
        }

        public List<Transaction> GetTransactions(int accountId)
        {
            List<Transaction> transactions = new List<Transaction>();
            using SqlConnection conn = DBConnUtil.GetConnection(connectionString);
            conn.Open();
            string query = "SELECT * FROM Transactions WHERE AccountId = @AccountId ORDER BY TransactionDate DESC";
            using SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@AccountId", accountId);
            using SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                transactions.Add(new Transaction
                {
                    TransactionId = (int)reader["TransactionId"],
                    AccountId = (int)reader["AccountId"],
                    Type = reader["Type"].ToString(),
                    Amount = (decimal)reader["Amount"],
                    TransactionDate = (DateTime)reader["TransactionDate"]
                });
            }
            return transactions;
        }
    }
}