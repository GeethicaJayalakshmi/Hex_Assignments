﻿using System.Configuration;

namespace BankAssignment.util
{
    public static class DBPropertyUtil
    {
        public static string GetConnectionString(string key)
        {
            // Ideally reading from app.config or hardcoded for now
            return "Server=LAPTOP-R19DI30G;Database=HMBank;Integrated Security=True;TrustServerCertificate=True";
        }
    }
}
